//. Predict the output of the following JavaScript code?
console.log("(-1 / 0): " + -1 / 0); // Output: -Infinity
console.log("(1 / 0): " + 1 / 0); // Output: Infinity
console.log("(0 / 0): " + 0 / 0); // Output: NaN
console.log("(0 / 1): " + 0 / 1); // Output: 0

//Q. Predict the output of the following JavaScript code?
var a = 4;
var b = "5";
var c = 6;

console.log("(a + b): " + (a + b)); // Output: 45
console.log("(a - b): " + (a - b)); // Output: -1
console.log("(a * b): " + a * b); // Output: 20
console.log("(a / b): " + a / b); // Output: 0.8
console.log("(a % b): " + (a % b)); // Output: 4


//@ MAX of array 
var Number = [10,20,12,111,10121];
var maxNumber = Math.max(...Number);
console.log(maxNumber);

// check the IFFEE
console.log(" check the IFFEE");
(function () {
  let  a = (b = 3);
})();
console.log("a defined? " + (typeof a !== "undefined")); // Output: true
console.log("b defined? " + (typeof b !== "undefined")); // Output: true
//check the ===
//Q. Predict the output of the following JavaScript code?

console.log("//check the ===");
console.log(0.1 + 0.2); // Output: 0.30000000000000004  15 zero 
console.log(0.1 + 0.2 == 0.3); // Output: false
//Q. Predict the output of the following JavaScript code?
var arr1 = "john".split("");
var arr2 = arr1.reverse();
var arr3 = "jones".split("");
arr2.push(arr3);
console.log(""+arr2.push(arr3));
console.log("array 1: length=" + arr1.length + " last=" + arr1.slice(-1)); //array 1: length=5 last=j,o,n,e,s
console.log("array 2: length=" + arr2.length + " last=" + arr2.slice(-1)); //array 2: length=5 last=j,o,n,e,s


//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 10 ");
console.log(1 + "2" + "2"); // Output: 122
console.log(1 + +"2" + "2"); // Output: 32
console.log(1 + -"1" + "2"); // Output: 02
console.log(+"1" + "1" + "2"); // Output: 112
console.log("A" - "B" + "2"); // Output: NaN2
console.log("A" - "B" + 2); // Output: NaN

/////
for (var i = 0; i < 5; i++) {
  setTimeout(function () {
    //console.log(i);
  }, i * 1000);
}
// Output: 145, 5, 5, 5, 5, 5

//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 11 ");
for (var i = 0; i < 5; i++) {
  (function (x) {
    setTimeout(function () {
      //console.log(x);
    }, x * 1000);
  })(i);
}
//Output:- 0, 1, 2, 3, 4
//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 12 ");
console.log(false == "0"); // Output: true
console.log(false === "0"); // Ou

//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 13 ");
var a = {},
  b = { key: "b" },
  c = { key: "c" };

a[b] = 123;
a[c] = 456;
console.log(a[b]); // Output: 456
console.log(a[c]); // Output: 456

//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 14 ");

(function (x) {
  return (function (y) {
    console.log(x); //1
  })(2);
})(10);


//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 15 ");
var hero = {
  _name: "John Doe",
  getSecretIdentity: function () {
    return this._name;
  },
};
var stoleSecretIdentity = hero.getSecretIdentity;

console.log(stoleSecretIdentity()); // Output: undefined
console.log(hero.getSecretIdentity()); // Output: John 

//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 16 ");
let  x = 21;
var girl = function () {
  console.log(x); // Output: undefined
  var x = 20;
};
girl();

//Q. Predict the output of the following JavaScript code?
console.log("-----excersise 17 ");

console.log( typeof undefined); // Output: string
console.log( typeof NaN); // Output: string
console.log( typeof null); // Output: string


console.log("-----excersise 18 ");

let arr = [1, 2];
arr.push(3)
arr.unshift(30)
arr.shift()
arr.pop()

console.log(...arr); // Output: 1, 2, 3

console.log("-----excersise 19 ");
let sum = (a, b) => {
  a + b;
};
console.log(sum(10, 20)); // Output: undefined; return keyword is missing

console.log("-----excersise 20 ");

var arr1 = ["javascript", "typescript", "es6"];
var searchValue = (value) => {
  return arr1.filter((item) => {
    return item.indexOf(value) > -1;
  });
};
console.log(...searchValue("script"));

console.log("-----excersise 21 ");

var a = [1, 2, 3, 4];
function sumUsingFunction(acc, value) {
  return acc + value;
}
var sumOfArrayUsingFunc = a.reduce(sumUsingFunction);
console.log(sumOfArrayUsingFunc);

console.log("-----excersise 22 ");

var output = (function (x) {
  delete x;
  return x;
})(0);


console.log(output);
// The code above will output 0 as output. delete operator is used to delete a property from an object. Here x is not an object it's local variable. delete operator doesn't affect local variables.

var x1 = 1;
var output = (function () {
  delete x;
  return x1;
})();

console.log(output);


var x3 = { foo: 1 };
var output = (function () {
  delete x3.foo;
  return x3.foo;
})();

console.log(output);
// The code above will output undefined as output. delete operator is used to delete a property from an object. Here x is an object which has foo as a property and from a self-invoking function, we are deleting the foo property of object x and after deletion, we are trying to reference deleted property foo which result undefined.
